package co.edu.uniquindio.poo;

public record Mascota(String nombre, String especie , String raza , byte edad , String genero , String color , byte peso, String numerodeIdentificacion) {
    public Mascota{
        assert nombre != null && !nombre.isBlank();
        assert especie != null && !especie.isBlank();
        assert raza != null && !raza.isBlank();
        assert genero != null && !genero.isBlank();
        assert color != null && !color.isBlank();
        assert numerodeIdentificacion != null && !numerodeIdentificacion.isBlank();
        assert edad >= 0; 
        assert peso > 0;
    }
}


