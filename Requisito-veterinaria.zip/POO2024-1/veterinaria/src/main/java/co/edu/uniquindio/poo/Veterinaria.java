package co.edu.uniquindio.poo;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

public class Veterinaria {
    private final String nombre;
    private  final Collection<Mascota> listaMascotas;

    public Veterinaria (String nombre){
        this.nombre = nombre;
        assert nombre != null && !nombre.isBlank();
        this.listaMascotas = new LinkedList <Mascota>();
    }

    public String getNombre(){
        return nombre;
    }

    public Collection<Mascota> getListaMascotas() {
        return listaMascotas;
    }

    public Collection<Mascota> getlisMascotas(){
        return Collections.unmodifiableCollection(listaMascotas);
    }
    public void registrarMascota(Mascota mascota) {
        assert verificarNumeroIdentificacion(mascota.numerodeIdentificacion()) == false : "Ya existe una mascota con esa identificacion" + mascota.numerodeIdentificacion();
        listaMascotas.add(mascota);
    }

    private boolean verificarNumeroIdentificacion (String numerodeIdentificacion){
        boolean exiteMascota = false;
        for (Mascota mascota : listaMascotas){
            if (mascota.numerodeIdentificacion().equals(numerodeIdentificacion)){
                exiteMascota = true;
            } 
        }
        return exiteMascota;
    }
}

