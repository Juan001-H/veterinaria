package co.edu.uniquindio.poo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Collection;
import java.util.LinkedList;
import java.util.logging.Logger;

import org.junit.jupiter.api.Test;

public class VeterinariaTest {
    private static final Logger LOG = Logger.getLogger(VeterinariaTest.class.getName());

    @Test
    public void datosCompletos(){
        LOG.info("Inicio Prueba datos completos");
        Veterinaria veterinaria = new Veterinaria("Amigos Peludos");
        assertEquals("Amigos Peludos", veterinaria.getNombre());
        LOG.info("Fin de la prueba datos completos");
    }

    @Test
    public void registrarMascota(){
        LOG.info("Iniciando el registro de la  mascota");
        Veterinaria veterinaria = new Veterinaria("Amigos Peludos");
        Mascota mascota = new Mascota("tobias","perro","bulldog frances", (byte)10, "Masculino" , "Blanco" , (byte)2,"1"); 
        veterinaria.registrarMascota(mascota);
        LOG.info("Finalizando el registro de la mascota");

    }

    @Test
    public void datosNulos(){
        LOG.info("Iniciando Prueba de datos nulos");
        assertThrows(Throwable.class,()-> new Veterinaria(null));
        LOG.info("Finalizando prueba de datos nulos");
    }

    @Test
    public void mascotasRepetidas(){
        LOG.info("Inicio prueba mascotas repetidas");
        Veterinaria veterinaria = new Veterinaria("Amigos Peludos");
        Mascota mascota = new Mascota("kira", "perro", "criollo", (byte)6, "Femenino", "Blanco", (byte)40, "1");
        veterinaria.registrarMascota(mascota);
        Mascota mascota2 = new Mascota("toby", "perro", "pastor aleman", (byte)3, "Masculino", "amarillo", (byte)15, "2");
        veterinaria.registrarMascota(mascota2);
        LOG.info("Fin prueba mascotas repetidas");

    }
    @Test
    public void obteberMayoresde10Años(){
        LOG.info("Inicio prueba mascotas obtener nombres");
        Veterinaria veterinaria = new Veterinaria("Amigos Peludos");

        Mascota mascota1 = new Mascota("Mateo", "perro", "pincher", (byte)15, "masculino", "Blanco", (byte)40, "1");
        Mascota mascota2 = new Mascota("Dante", "perro", "pastor aleman", (byte)12, "Masculino", "amarillo", (byte)15, "2");
        Mascota mascota3 = new Mascota("Princesa", "gato", "siames", (byte)13, "femenino", "gris", (byte)11, "3");
        Mascota mascota4 = new Mascota("toby", "perro", "criollo", (byte)16, "Masculino", "verde", (byte)50, "4");
        Mascota mascota5 = new Mascota("samara", "gato", "siames", (byte)13, "femenino", "gris", (byte)11, "22");
        Mascota mascota6= new Mascota("simon", "perro", "bulldog", (byte)16, "Masculino", "verde", (byte)50, "111");

        veterinaria.registrarMascota(mascota1);
        veterinaria.registrarMascota(mascota2);
        veterinaria.registrarMascota(mascota3);
        veterinaria.registrarMascota(mascota4);
        veterinaria.registrarMascota(mascota5);
        veterinaria.registrarMascota(mascota6);
        Collection<Mascota> mascotasMayoresDeDiez = new LinkedList<Mascota>();

        for (Mascota mascota : veterinaria.getlisMascotas()) {
            if (mascota.edad() > 10) {
            mascotasMayoresDeDiez.add(mascota);
        }
}

        System.out.println("Mascotas mayores de 10 años:");
        for (Mascota mascota : mascotasMayoresDeDiez) {
            System.out.println(mascota.nombre());
        }
        LOG.info("fin prueba mascotas obtener nombres");
    }

}

