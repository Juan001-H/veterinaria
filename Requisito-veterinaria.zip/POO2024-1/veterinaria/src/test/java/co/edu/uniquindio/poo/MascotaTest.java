package co.edu.uniquindio.poo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.logging.Logger;

import org.junit.jupiter.api.Test;

public class MascotaTest {
    private static final Logger LOG = Logger.getLogger(MascotaTest.class.getName());
    @Test
    public void datosCompletos(){
        
    LOG.info("Iniciando pruebas datos completos");
    Mascota mascota = new Mascota ("Simon","Perro","bulldog", (byte)3, "Masculino" , "negro" , (byte)20,"10858585");
    assertEquals("Simon", mascota.nombre());
    assertEquals("Perro", mascota.especie());
    assertEquals("bulldog", mascota.raza());
    assertEquals((byte)3, mascota.edad());
    assertEquals("Masculino", mascota.genero());
    assertEquals("negro", mascota.color());
    assertEquals((byte)20, mascota.peso());
    assertEquals("10858585", mascota.numerodeIdentificacion());
    LOG.info("Finalizando prueba datos completos");
}
@Test
public void datosVacios(){
    LOG.info("Inicio prueba datos vacios");
    assertThrows(Throwable.class,() -> new Mascota("juan", "00","",(byte)1,"","",(byte)20,""));
        LOG.info("fin prueba datos vacios");
} 

@Test
public void valoresNegativos(){
    LOG.info("Inicio prueba  datos negativos");
    assertThrows(Throwable.class, ()-> new Mascota ("Lupe","Perro","Criollo", (byte)-3, "Hembra" , "Cafe" , (byte)-54,"1092455543"));
    LOG.info("Fin de la prueba datos negativos");

}
@Test
    public void numerosGrandes() {
        LOG.info("Inicio pruebas numeros Grandes");
        assertThrows(Throwable.class, ()-> new Mascota ("Lupe","Perro","Criollo", (byte)200, "Hembra" , "Cafe" , (byte)2000,"1092455543"));
        LOG.info("Fin de la prueba numeros grandes");
}
}